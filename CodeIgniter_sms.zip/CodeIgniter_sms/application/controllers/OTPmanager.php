<?php

defined('BASEPATH') or exit('No direct script access allowed');

// Load the autuloader
require_once FCPATH . '/vendor/autoload.php';

use Twilio\Rest\Client;

class OTPmanager extends CI_Controller
{
    private $sid;
    private $token;

    public function __construct()
    {
        parent::__construct();
        $this->sid = "ACeaf3903c6a3b6b864641545addb806d1";
        $this->token = "404e511f58bd4e0e3258a54ea866c399";
    }


    public function index()
    {
        $this->load->view('otpdemo');
    }


    public function send_otp_sms()
    {
        $otp = $this->generate_otp();

        // For demo I'm using session to store the OTP,  you might want to store it in the DB
        $_SESSION['user_otp'] = $otp;

        // Reciever's phone number
        $phone_number = $this->input->post('phone');

        // Create Twilio client
        $client = new Client($this->sid, $this->token);

        // Use the client to do fun stuff like send text messages!
        $client->messages->create(
            // the number you'd like to send the message to
            $phone_number,
            array(
                // A Twilio phone number for testing purpose
                'from' => '+14029205213',
                // the body of the text message you'd like to send
                'body' => 'Here is your OTP! ' . $otp
            )
        );

        // Redirect to the verfication page
        redirect(base_url('OTPmanager/verfiy'));

        // redirect('manage_categori');
        // echo '<pre>';
        // print_r($phone_number);
        //     exit();
    }


    public function verfiy()
    {
        // Load the form to verfiy OTP
        $this->load->view('otpverify');
    }


    public function verify_otp()
    {
        // Get the otp value 
        $user_otp = $this->input->post('otp');

        if ($user_otp == $_SESSION['user_otp']) {
            echo " OTP is valid...";
        } else {
            echo "This OTP is invalid Or expired!!!";
        }
    }


    private function generate_otp(int $length = 4)
    {
        $otp = "";
        $numbers = "0123456789";

        for ($i = 0; $i < $length; $i++) {
            $otp .= $numbers[rand(0, strlen($numbers) - 1)];
        }

        return $otp;
    }
}

/* End of file OTPmanager.php */
